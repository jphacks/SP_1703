//
//  TOPController.swift
//  カロリーアプリ
//
//  Created by 弦間奨 on 2017/10/28.
//  Copyright © 2017年 奨 弦間. All rights reserved.
//

import UIKit

/*suzuki追加文始まり***********************************************************/
import Foundation
/*suzuki追加文終わり***********************************************************/

//Alamofireライブラリをインポート
import Alamofire

class TOPController: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {

    /*suzuki追加文始まり***********************************************************/
    // 正規表現にマッチした文字列を格納した配列を返す
    func getMatchStrings(targetString: String, pattern: String) -> [String] {
        
        var matchStrings:[String] = []
        
        do {
            
            let regex = try NSRegularExpression(pattern: pattern, options: [])
            let targetStringRange = NSRange(location: 0, length: (targetString as NSString).length)
            
            let matches = regex.matches(in: targetString, options: [], range: targetStringRange)
            
            for match in matches {
                
                // rangeAtIndexに0を渡すとマッチ全体が、1以降を渡すと括弧でグループにした部分マッチが返される
                let range = match.rangeAt(0)
                let result = (targetString as NSString).substring(with: range)
                
                matchStrings.append(result)
            }
            
            return matchStrings
            
        } catch {
            print("error: getMatchStrings")
        }
        return []
    }//正規表現関数ココまで
    /*suzuki追加文終わり***********************************************************/
    
    @IBOutlet var photoImageView: UIImageView! //写真表示用ImageView

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //「カメラ」ボタンを押した時に呼ばれるメソッド
    @IBAction func onTappedCameraButton() {
        presentPickerController(sourceType: .camera)
    }
    
    //「アルバム」ボタンを押した時に呼ばれるメソッド 
    @IBAction func onTappedAlbumButton() {
        presentPickerController(sourceType: .photoLibrary)
    }
    
    //「登録」ボタンを押した時に呼ばれるメソッド
    @IBAction func onTappedTourokuButton() {
        print("登録ボタンが入力されました")
        
        if photoImageView.image != nil {
            //presentPickerController(sourceType: .photoLibrary)
            //super.viewDiaLoad()
            //let image = UIImage(named: "/Users/suzukigenki/Desktop/JPHACK/iOSApp/カロリーアプリ/01.jpg")!
            //let image = UIImage(named: "/Users/suzukigenki/Desktop/JPHACK/iOSApp/カロリーアプリ/01.jpg")!
            let NSImage = UIImageJPEGRepresentation(photoImageView.image!, 0.5)
            
            print("画像の登録！！！")
            Alamofire.upload(
                multipartFormData: { multipartFormData in
                    // 送信する値の指定
                    //print(NSImage)
                    multipartFormData.append(NSImage!, withName: "image", fileName: "01.jpg", mimeType: "image/jpg")
                    //multipartFormData.append(sendSTR.data(using: String.Encoding.utf8)!, withName: "userId")
            },
                to: "https://www3.arche.blue/mvp5/v1/1078/search",
                //"http://appcre.net/rss.php",//"https://www3.arche.blue/mvp5/v1/1078/search",
                encodingCompletion: { encodingResult in
                    switch encodingResult {
                    case .success(let upload, _, _):
                        upload.responseJSON { response in
                            /*suzuki追加文始まり***********************************************************/
                            //print(response.request!)  // original URL request
                            //print(response.response!) // URL response
                            //print(response.data!)     // server data
                            //print(response.result)   // result of response serialization
                            //let personalData: String = String(describing: response.result.value)//Data
                            //print(personalData)
                            let str: String = String(describing: response.result.value)//Data
                            
                            //let result = message.stringByReplacingOccurrencesOfString(" ", withString: "", options: NSStringCompareOptions.LiteralSearch, range: nil)
                            let personalData1 = str.replacingOccurrences(of:" ", with:"")
                            let personalData = personalData1.replacingOccurrences(of:"\n", with:"")
                            
                            //print(personalData)//jsonデータから空白文字と改行文字を除去した文字列をひょうじ
                            
                            // 対象の文字列
                            let targetString = personalData//"absodihogeoaispogejihadfoostestaiodaosj"
                            
                            // 正規表現パターン
                            let matchPattern = "=.*?\"\""
                            //"associatedInfo.*?””"//".*associatedInfo(.*));.*"//hoge|foo|a.?s"
                            
                            //print("正規表現1")
                            // マッチした文字列をすべて表示
                            let matches = self.getMatchStrings(targetString: targetString, pattern: matchPattern)
//                            for str in matches {
//                                print(str)
//                            }
                            
                            //カロリーの抽出
                            let matchPattern2 = "([0-9])"
                            let matches_st: String = String(describing: matches)
                            let matches2 = self.getMatchStrings(targetString: matches_st, pattern: matchPattern2)
                            let kcal_pst = matches2.joined(separator: ",")
                            let kcal_st = kcal_pst.replacingOccurrences(of:",", with:"")
                            let d_kcal = Int(kcal_st)!
                            print("カロリー")
                            print(d_kcal)
                            
                            
                            //商品名の抽出
                            let matchPattern3 = "([A-Za-z])"
                            let matches_st2: String = String(describing: matches)
                            let matches3 = self.getMatchStrings(targetString: matches_st2, pattern: matchPattern3)
                            let name_pst = matches3.joined(separator: ",")
                            let d_name = name_pst.replacingOccurrences(of:",", with:"")
                            print("商品名")
                            print(d_name)
                        }
                    case .failure(let encodingError):
                        // 失敗
                        print(encodingError)
                        print("アップロード失敗！！！")
                    }
                    /*suzuki追加文終わり***********************************************************/
                }
            )
            print("認識終了！！！")
        }else{
            print("画像がありません")
        }
        
    }

    
    
    // カメラ、アルバムの呼び出しメソッド(カメラorアルバムのソースタイプが引数)
    func presentPickerController(sourceType: UIImagePickerControllerSourceType) {

        if UIImagePickerController.isSourceTypeAvailable(sourceType) {
            let picker = UIImagePickerController()
            picker.sourceType = sourceType
            picker.delegate = self
            self.present(picker, animated: true, completion: nil)
        }
    }
    
    // 写真が選択された時に呼び出されるメソッド
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        self.dismiss(animated: true, completion: nil)
        // 画像を出力
        photoImageView.image = info[UIImagePickerControllerOriginalImage] as? UIImage
    }
    
}
