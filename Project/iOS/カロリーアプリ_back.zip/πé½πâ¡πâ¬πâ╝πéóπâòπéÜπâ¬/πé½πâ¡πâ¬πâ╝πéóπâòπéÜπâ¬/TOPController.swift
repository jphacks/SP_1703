//
//  TOPController.swift
//  カロリーアプリ
//
//  Created by 弦間奨 on 2017/10/28.
//  Copyright © 2017年 奨 弦間. All rights reserved.
//

import UIKit

//Alamofireライブラリをインポート
import Alamofire

class TOPController: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {

    
    @IBOutlet var photoImageView: UIImageView! //写真表示用ImageView

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //「カメラ」ボタンを押した時に呼ばれるメソッド
    @IBAction func onTappedCameraButton() {
        presentPickerController(sourceType: .camera)
    }
    
    //「アルバム」ボタンを押した時に呼ばれるメソッド 
    @IBAction func onTappedAlbumButton() {
        presentPickerController(sourceType: .photoLibrary)
    }
    
    //「送信」ボタンを押した時に呼ばれるメソッド
    @IBAction func onTappedTourokuButton() {
        //presentPickerController(sourceType: .photoLibrary)
        //super.viewDiaLoad()
        print("登録！！！")
        let image = UIImage(named: "/Users/suzukigenki/Desktop/JPHACK/iOSApp/カロリーアプリ/02.jpg")!
        let NSImage = UIImageJPEGRepresentation(image, 0.5)
        
        print("画像の登録！！！")
        
        Alamofire.upload(
            multipartFormData: { multipartFormData in
                // 送信する値の指定
                //print(NSImage)
                multipartFormData.append(NSImage!, withName: "image", fileName: "02.jpg", mimeType: "image/jpg")
                //multipartFormData.append(sendSTR.data(using: String.Encoding.utf8)!, withName: "userId")
        },
            to: "https://www3.arche.blue/mvp5/v1/1078/search",//"http://appcre.net/rss.php",
            encodingCompletion: { encodingResult in
                switch encodingResult {
                case .success(let upload, _, _):
                    upload.responseJSON { response in
                        // 成功
                        print("アップロード成功！！！")
                        let responseData = response
                        print(responseData)
                        //print(responseData ?? "成功")
                    }
                case .failure(let encodingError):
                    // 失敗
                    print(encodingError)
                    print("アップロード失敗！！！")
                }
        }
        )
    }

    
    
    // カメラ、アルバムの呼び出しメソッド(カメラorアルバムのソースタイプが引数) 
    func presentPickerController(sourceType: UIImagePickerControllerSourceType) {

        if UIImagePickerController.isSourceTypeAvailable(sourceType) {
            let picker = UIImagePickerController()
            picker.sourceType = sourceType
            picker.delegate = self
            self.present(picker, animated: true, completion: nil)
        }
    }
    
    // 写真が選択された時に呼び出されるメソッド
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        self.dismiss(animated: true, completion: nil)
        // 画像を出力
        photoImageView.image = info[UIImagePickerControllerOriginalImage] as? UIImage
    }
    
}
