//
//  TOPController.swift
//  カロリーアプリ
//
//  Created by 弦間奨 on 2017/10/28.
//  Copyright © 2017年 奨 弦間. All rights reserved.
//

import UIKit

//Alamofireライブラリをインポート
import Alamofire

class TOPController: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {

    
    @IBOutlet var photoImageView: UIImageView! //写真表示用ImageView
    @IBOutlet var photolabel: UILabel! //写真表示lavel
    @IBOutlet var photocalory: UILabel! //写真表示calory
    @IBOutlet var photononlabel: UILabel! //写真ない時の表示lavel
    @IBOutlet var photocomp: UIButton! //写真完了


    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //「カメラ」ボタンを押した時に呼ばれるメソッド
    @IBAction func onTappedCameraButton() {
        presentPickerController(sourceType: .camera)
    }
    
    //「アルバム」ボタンを押した時に呼ばれるメソッド 
    @IBAction func onTappedAlbumButton() {
        presentPickerController(sourceType: .photoLibrary)
    }
    
    @IBAction func onTappedCompButton() {
        presentPickerController(sourceType: .photoLibrary)
    }
    
    //「登録」ボタンを押した時に呼ばれるメソッド
    @IBAction func onTappedTourokuButton() {
        print("入った!")
        
        if photoImageView.image != nil {
            print("写真あり")
            //photononlabel.text = ""
            
            //presentPickerController(sourceType: .photoLibrary)
            //super.viewDiaLoad()
            print("登録！！！")
            //let image = UIImage(named: "/Users/suzukigenki/Desktop/JPHACK/iOSApp/カロリーアプリ/01.jpg")!
            
            //let image = UIImage(named: "/Users/suzukigenki/Desktop/JPHACK/iOSApp/カロリーアプリ/01.jpg")!
            /*let NSImage = UIImageJPEGRepresentation(photoImageView.image!, 0.5)
            
            print("画像の登録！！！")
            
            Alamofire.upload(
                multipartFormData: { multipartFormData in
                    // 送信する値の指定
                    //print(NSImage)
                    multipartFormData.append(NSImage!, withName: "image", fileName: "01.jpg", mimeType: "image/jpg")
                    //multipartFormData.append(sendSTR.data(using: String.Encoding.utf8)!, withName: "userId")
            },
                to: "https://www3.arche.blue/mvp5/v1/1078/search",
                //"http://appcre.net/rss.php",//"https://www3.arche.blue/mvp5/v1/1078/search",
                encodingCompletion: { encodingResult in
                    switch encodingResult {
                    case .success(let upload, _, _):
                        upload.responseJSON { response in
                            // 成功
                            print("アップロード成功！！！")
                            let responseData = response
                            print(responseData)
                            //print(responseData ?? "成功")
                        }
                    case .failure(let encodingError):
                        // 失敗
                        print(encodingError)
                        print("アップロード失敗！！！")
                    }
                }
            )
            photolabel.text = "aaaa"
            photocalory.text = "bbbb"
            
            //let text1 = "写真の名称"
            
            //photolabel.text = text1
            */
        }else{
            print("画像がありません")
            photononlabel.text = "飲み物を撮影してください"
        }
        
    }

    func drawText(image: UIImage) -> UIImage {
    // テキストの内容の設定 
        let text = "LifeisTech!"
    // textFontAttributes: 文字の特性[フォントとサイズ、カラー、スタイル]の設定 
        let textFontAttributes = [
            NSFontAttributeName: UIFont(name: "Arial", size: 120)!,
            NSForegroundColorAttributeName: UIColor.red]
        
        // グラフィックスコンテキスト生成,編集を開始
        UIGraphicsBeginImageContext(image.size)
        
        // 読み込んだ写真を書き出す
        image.draw(in: CGRect(x: 0, y: 0, width: image.size.width, height: image.size.height))
        
        //定義 CGRect(x: [左からのx座標]px, y: [上からのy座標]px, width: [横の長さ]px, height: [縦の長さ]px)
        let margin: CGFloat = 5.0 // 余白
        let textRect = CGRect(x: margin, y: margin, width: image.size.width - margin, height: image.size.height - margin)
        // textRectで指定した範囲にtextFontAttributesにしたがってtextを描き出す 
        text.draw(in: textRect, withAttributes: textFontAttributes)
        // グラフィックスコンテキストの画像を取得
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        // グラフィックスコンテキストの編集を終了 
        UIGraphicsEndImageContext()
        return newImage!
    }
    
    // カメラ、アルバムの呼び出しメソッド(カメラorアルバムのソースタイプが引数)
    func presentPickerController(sourceType: UIImagePickerControllerSourceType) {
        photononlabel.text = ""
        photolabel.text = ""
        photocalory.text = ""
        if UIImagePickerController.isSourceTypeAvailable(sourceType) {
            let picker = UIImagePickerController()
            picker.sourceType = sourceType
            picker.delegate = self
            self.present(picker, animated: true, completion: nil)
        }
    }
    
    // 写真が選択された時に呼び出されるメソッド
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        self.dismiss(animated: true, completion: nil)
        // 画像を出力
        photoImageView.image = info[UIImagePickerControllerOriginalImage] as? UIImage
        
        let NSImage = UIImageJPEGRepresentation(photoImageView.image!, 0.5)
        
        print("画像の登録！！！")
        
        Alamofire.upload(
            multipartFormData: { multipartFormData in
                // 送信する値の指定
                //print(NSImage)
                multipartFormData.append(NSImage!, withName: "image", fileName: "01.jpg", mimeType: "image/jpg")
                //multipartFormData.append(sendSTR.data(using: String.Encoding.utf8)!, withName: "userId")
        },
            to: "https://www3.arche.blue/mvp5/v1/1078/search",
            //"http://appcre.net/rss.php",//"https://www3.arche.blue/mvp5/v1/1078/search",
            encodingCompletion: { encodingResult in
                switch encodingResult {
                case .success(let upload, _, _):
                    upload.responseJSON { response in
                        // 成功
                        print("アップロード成功！！！")
                        let responseData = response
                        print(responseData)
                        //print(responseData ?? "成功")
                    }
                case .failure(let encodingError):
                    // 失敗
                    print(encodingError)
                    print("アップロード失敗！！！")
                }
        }
        )
        photolabel.text = "aaaa"
        photocalory.text = "bbbb"

        //photolabel.text = "aabb"
    }
    
}
